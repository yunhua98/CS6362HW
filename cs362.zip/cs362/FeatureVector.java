package cs362;

import java.io.Serializable;
import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;

public class FeatureVector implements Serializable {
	private Map<Integer, Double> map = new HashMap<>();
	private int length = 0;

	public void add(int index, double value) {
		map.put(index, value);
		if (index > length) {
			length = index;
		}
	}

	public double get(int index) {
		return map.getOrDefault(index, 0.0);
	}

	public Iterator<Integer> keyIterator() {
		return map.keySet().iterator();
	}

	public boolean containsKey(int index) {
		return map.containsKey(index);
	}

	public int size() {
		return length;
	}
}
