package cs362;

import java.io.Serializable;
import java.util.List;
import java.util.HashMap;
import java.util.Map;
import java.util.Iterator;

public class EvenOddPredictor extends Predictor {
  private static final long serialVersionUID = 1L;
  private static final Label EVEN_LABEL = new ClassificationLabel(1);
  private static final Label ODD_LABEL = new ClassificationLabel(0);  

	public void train(List<Instance> instances) {
  }

	public Label predict(Instance instance) {
    FeatureVector vector = instance.getFeatureVector();
    Iterator<Integer> iterator = vector.keyIterator();

    double[] sums = new double[2];

    while (iterator.hasNext()) {
      int key = iterator.next();
      sums[key % 2] += vector.get(key);
    }

    return sums[0] >= sums[1] ? EVEN_LABEL : ODD_LABEL;
  }
}
