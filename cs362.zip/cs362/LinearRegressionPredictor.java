package cs362;

import java.io.Serializable;
import java.util.Iterator;

import org.apache.commons.math3.linear.*;
import java.lang.Math.*;
import java.util.List;

public class LinearRegressionPredictor extends Predictor {
  private static final long serialVersionUID = 1L;
  private RealVector weights = null;
  private int vectorLen = 0;

  public void train(List<Instance> instances) {
    // Need to find the max length of one of the vectors
    int maxLen = 0;

    for (Instance instance : instances) {
      Iterator<Integer> iterator = instance.getFeatureVector().keyIterator();
      while (iterator.hasNext()) {
        maxLen = Math.max(iterator.next(), maxLen);
      }
    }

    maxLen += 1;
    // We have the max length now
    double[][] matrixData = new double[instances.size()][maxLen];

    double[] yData = new double[instances.size()];

    for (int i = 0; i < instances.size(); ++i) {
      FeatureVector vector = instances.get(i).getFeatureVector();
      Iterator<Integer> iterator = vector.keyIterator();

      matrixData[i][0] = 1;
      while (iterator.hasNext()) {
        int key = iterator.next();
        matrixData[i][key] = vector.get(key);
      }

      // Assign the y vector as well
      yData[i] = Double.parseDouble(instances.get(i).getLabel().toString());
    }

    RealMatrix matrix = MatrixUtils.createRealMatrix(matrixData);
    RealVector y = MatrixUtils.createRealVector(yData);

    RealMatrix matrixTranspose = matrix.transpose();

    RealMatrix mult = matrixTranspose.multiply(matrix);
    RealMatrix inv = new LUDecomposition(mult).getSolver().getInverse();

    RealMatrix xBlock = inv.multiply(matrixTranspose);

    weights = xBlock.operate(y);
    System.out.println(weights);
    System.out.println(mult);
    vectorLen = maxLen;
  }

  public Label predict(Instance instance) {
    double[] data = new double[vectorLen];
    FeatureVector vector = instance.getFeatureVector();
    Iterator<Integer> iterator = vector.keyIterator();

    data[0] = 1;

    while (iterator.hasNext()) {
      int key = iterator.next();
      data[key] = vector.get(key);
    }

    RealVector instanceVector = MatrixUtils.createRealVector(data);

    double dotProduct = weights.dotProduct(instanceVector);

    return new RegressionLabel(dotProduct);
  }
}
