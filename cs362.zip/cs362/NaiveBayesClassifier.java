package cs362;

import java.util.List;
import java.util.Arrays;
import java.io.Serializable;
import java.util.Iterator;

import org.apache.commons.math3.linear.*;
import java.lang.Math.*;

public class NaiveBayesClassifier extends Predictor {
  private static final long serialVersionUID = 1L;
  private static final String trueLabelString = "1";
  private static final ClassificationLabel trueLabel = new ClassificationLabel(1);
  private static final ClassificationLabel falseLabel = new ClassificationLabel(0);
  private double percentageTrue = 0;
  private double[] percentageXGivenTrue = null;
  private double[] percentageXGivenFalse = null;
  private int vectorSize;
  private double lambda;

  public NaiveBayesClassifier(double lambda) {
    this.lambda = lambda;
  }

  public void train(List<Instance> instances) {
    float numTrue = 0;
    vectorSize = 0;

    for (Instance instance : instances) {
      if (instance.getLabel().toString().equals(trueLabelString)) {
        numTrue++;
      }
      vectorSize = Math.max(vectorSize, instance.getFeatureVector().size());
    }

    percentageTrue = numTrue / instances.size();

    percentageXGivenTrue = new double[vectorSize];
    percentageXGivenFalse = new double[vectorSize];
    Arrays.fill(percentageXGivenTrue, lambda);
    Arrays.fill(percentageXGivenFalse, lambda);

    for (Instance instance : instances) {
      double[] refArray = percentageXGivenTrue;
      if (!instance.getLabel().toString().equals(trueLabelString)) {
        refArray = percentageXGivenFalse;
      }

      FeatureVector vector = instance.getFeatureVector();
      Iterator<Integer> iterator = vector.keyIterator();
      while (iterator.hasNext()) {
        int key = iterator.next();
        if (vector.get(key) >= .5) {
          refArray[key - 1]++;
        }
      }
    }

    float numFalse = instances.size() - numTrue;
    for (int i = 0; i < vectorSize; ++i) {
      percentageXGivenTrue[i] /= numTrue;
      percentageXGivenFalse[i] /= numFalse;
    }
  }

  public Label predict(Instance instance) {
    if (percentageTrue == 1.0) {
      return trueLabel;
    } else if (percentageTrue == 0.0) {
      return falseLabel;
    }

    double logProbTrue = Math.log(percentageTrue);
    double logProbFalse = Math.log(1 - percentageTrue);
    FeatureVector vector = instance.getFeatureVector();
    Iterator<Integer> iterator = vector.keyIterator();

    while(iterator.hasNext()) {
      int key = iterator.next();
      if (vector.get(key) == 1 && key < vectorSize) {
        logProbTrue += Math.log(percentageXGivenTrue[key - 1]);
        logProbFalse += Math.log(percentageXGivenFalse[key - 1]);
      }
    }

    return logProbTrue >= logProbFalse ? trueLabel : falseLabel;
  }
}
