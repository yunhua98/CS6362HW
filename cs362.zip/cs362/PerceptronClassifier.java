package cs362;

import java.util.List;
import java.util.Arrays;
import java.io.Serializable;
import java.util.Iterator;

import org.apache.commons.math3.linear.*;
import java.lang.Math.*;

public class PerceptronClassifier extends Predictor {
  private static final long serialVersionUID = 1L;
  private static final String trueLabelString = "1";
  private static final ClassificationLabel trueLabel = new ClassificationLabel(1);
  private static final ClassificationLabel falseLabel = new ClassificationLabel(0);
  private final double learningRate;
  private final int iterations;
  private int vectorSize;
  private double[] weights;

  public PerceptronClassifier(double learningRate, int iterations) {
    this.learningRate = learningRate;
    this.iterations = iterations;
  }

  public void train(List<Instance> instances) {
    for (Instance instance : instances) {
      vectorSize = Math.max(vectorSize, instance.getFeatureVector().size());
    }

    weights = new double[vectorSize + 1];
    Arrays.fill(weights, 0);

    for (int i = 0; i < iterations; ++i) {
      iterate(instances);
    }

    for (int i = 0; i < weights.length; ++i) {
      System.out.println(weights[i]);
    }
  }

  public void iterate(List<Instance> instances) {
    for (Instance instance : instances) {
      FeatureVector vector = instance.getFeatureVector();
      double prod = dotProductWeights(vector);
      String predictedYLabel = "0";
      int predictedY = -1;
      if (prod >= 0) {
        predictedYLabel = "1";
        predictedY = 1;
      }

      if (!predictedYLabel.equals(instance.getLabel().toString())) {
        Iterator<Integer> iterator = vector.keyIterator();
        while (iterator.hasNext()) {
          int key = iterator.next();
          weights[key] += learningRate * predictedY * - 1 * vector.get(key);
        }
      }
    }
  }

  private double dotProductWeights(FeatureVector vector) {
    Iterator<Integer> iterator = vector.keyIterator();
    double ret = 0;
    while (iterator.hasNext()) {
      int key = iterator.next();
      ret += vector.get(key) * weights[key];
    }
    return ret;
  }

  public Label predict(Instance instance) {
    // for (int i = 0; i < weights.length; ++i) {
    //   System.out.println(weights[i]);
    // }

    double prod = dotProductWeights(instance.getFeatureVector());

    if (prod >= 0) {
      return trueLabel;
    } else {
      return falseLabel;
    }
  }
}
