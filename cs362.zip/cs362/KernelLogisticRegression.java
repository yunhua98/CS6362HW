package cs362;

import java.io.Serializable;
import java.util.Iterator;

import org.apache.commons.math3.linear.*;
import java.lang.Math.*;
import java.util.List;

public abstract class KernelLogisticRegression extends Predictor {
  private static final long serialVersionUID = 1L;
  private int vectorLen = 0;

  private ClassificationLabel TRUE = new ClassificationLabel(1);
  private ClassificationLabel FALSE = new ClassificationLabel(0);

  private double learningRate;
  private double iterations;

  private double[][] cacheMatrix;
  private double[] alphas;
  private List<Instance> instances;

  public KernelLogisticRegression(double learningRate, double iterations) {
    this.learningRate = learningRate;
    this.iterations = iterations;
  }

  public double getKernel(int x, int y) {
    return cacheMatrix[x][y];
  }

  public abstract double kernel(FeatureVector x, FeatureVector y);

  public void train(List<Instance> instances) {
    // Need to find the max length of one of the vectors
    int maxLen = 0;

    this.cacheMatrix = new double[instances.size()][instances.size()];
    this.instances = instances;

    for (int i = 0; i < instances.size(); ++i) {
      for (int j = 0; j < instances.size(); ++j) {
        //        System.out.println("kernel for " + i + ", " + j);
        cacheMatrix[i][j] = kernel(instances.get(i).getFeatureVector(), instances.get(j).getFeatureVector());
        //System.out.println("and the kernel is " + cacheMatrix[i][j]);
      }
    }
    for (Instance instance : instances) {
      Iterator<Integer> iterator = instance.getFeatureVector().keyIterator();
      while (iterator.hasNext()) {
        maxLen = Math.max(iterator.next(), maxLen);
      }
    }

    maxLen += 1;

    alphas = new double[instances.size()];

    for (int iteration = 0; iteration < iterations; ++iteration) {
      double[] newAlphas = new double[instances.size()];
      System.out.println("Iteration " + iteration);
      for (int i = 0; i < alphas.length; ++i) {
        System.out.println(iteration + " : " + alphas[i]);
      }
      // neg defaults to making the left function of left function negative
      for (int k = 0; k < instances.size(); ++k) {
        double sum = 0;

        for (int i = 0; i < instances.size(); ++i) {
          //double neg = instances.get(i).getLabel().equals("1") ? -1 : 1;
          double y = instances.get(i).getLabel().toString().equals("1") ? 1 : 0;
          double wTz = 0;

          for (int j = 0; j < instances.size(); ++j) {
            wTz += alphas[j] * getKernel(j, i);
          }

          //System.out.println("SUm of " + k + ", instance " + i + "Link: " + link(-1.0 * wTz) + "Kernel: " + getKernel(i, k));
          sum += y * link(-1.0 * wTz) * getKernel(i, k) + (1 - y) * link(wTz) * (-1.0 * getKernel(i, k));
        }

        newAlphas[k] = alphas[k] + learningRate * sum;
      }
      alphas = newAlphas;
    }
  }

  public double link(double z) {
    return 1.0 / (1.0 + Math.exp(-1.0 * z));
  }

  public Label predict(Instance instance) {
    double wTz = 0;
    for (int j = 0; j < instances.size(); ++j) {
      wTz += alphas[j] * kernel(instances.get(j).getFeatureVector(), instance.getFeatureVector());
    }
    System.out.println("wTz is " + wTz);
    System.out.println("link is " + link(wTz));
    return link(wTz) >= 0.5 ? TRUE : FALSE;
  }
}
