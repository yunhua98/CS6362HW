package cs362;

import java.io.Serializable;
import java.util.List;
import java.util.HashMap;
import java.util.Map;


public class MajorityPredictor extends Predictor {
	private static final long serialVersionUID = 1L;
  private Label label;

	public void train(List<Instance> instances) {
    Map<String, Integer> map = new HashMap<>();
    for (Instance instance : instances) {
      String labelString = instance.getLabel().toString();
      map.put(labelString, map.getOrDefault(labelString, 0) + 1);
    }

    int maxVal = -1;
    String max = "";

    for (Map.Entry<String, Integer> entry : map.entrySet()) {
      if (entry.getValue() > maxVal) {
        maxVal = entry.getValue();
        max = entry.getKey();
      } else if (entry.getValue() == maxVal) {
        max = ((int) Math.floor(Math.random() * 2)) == 1 ? max : entry.getKey();
      }
    }

    label = new ClassificationLabel(Integer.parseInt(max));
  }

	public Label predict(Instance instance) {
    return this.label;
  }
}
