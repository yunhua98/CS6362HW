package cs362;

import java.util.Iterator;
public class PolynomialKernelLogisticRegression extends KernelLogisticRegression {
  private double exponent;
  public PolynomialKernelLogisticRegression(double learningRate, double iterations, double exponent) {
    super(learningRate, iterations);
    System.out.println(learningRate + " : " + exponent + " : " + iterations);
    this.exponent = exponent;
  }

  public double kernel(FeatureVector x, FeatureVector y) {
    Iterator<Integer> iterator = x.keyIterator();
    double ret = 0;
    while (iterator.hasNext()) {
      int next = iterator.next();

      ret += x.get(next) * y.get(next);
    }
    //System.out.println(ret + " : exponent " + exponent);
    return Math.pow((1.0 + ret), exponent);
  }
}
