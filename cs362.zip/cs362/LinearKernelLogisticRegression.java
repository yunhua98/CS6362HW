package cs362;

import java.util.Iterator;
public class LinearKernelLogisticRegression extends KernelLogisticRegression {
  public LinearKernelLogisticRegression(double learningRate, double iterations) {
    super(learningRate, iterations);
  }

  public double kernel(FeatureVector x, FeatureVector y) {
    Iterator<Integer> iterator = x.keyIterator();
    double ret = 0;
    while (iterator.hasNext()) {
      int next = iterator.next();

      ret += x.get(next) * y.get(next);
    }
    return ret;
  }
}
