package cs362;

import java.util.Iterator;
public class GaussianKernelLogisticRegression extends KernelLogisticRegression {
  private double sigma;
  public GaussianKernelLogisticRegression(double learningRate, double iterations, double sigma) {
    super(learningRate, iterations);
    this.sigma = sigma;
  }

  public double kernel(FeatureVector x, FeatureVector y) {
    Iterator<Integer> iterator = x.keyIterator();
    double ret = 0;
    FeatureVector subbed = new FeatureVector();
    while (iterator.hasNext()) {
      int next = iterator.next();
      subbed.add(next, x.get(next) - y.get(next));
    }

    iterator = y.keyIterator();
    while (iterator.hasNext()) {
      int next = iterator.next();
      subbed.add(next, x.get(next) - y.get(next));
    }

    int squareSum = 0;
    iterator = subbed.keyIterator();

    while (iterator.hasNext()) {
      int next = iterator.next();
      squareSum += subbed.get(next) * subbed.get(next);
    }

    return Math.exp(-1 * squareSum / (2 * sigma * sigma));
  }
}
